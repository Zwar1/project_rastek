package com.example.userCrud.Repository;

import org.springframework.stereotype.Repository;

@Repository
public interface LeaveEvidenceRepository {
}
