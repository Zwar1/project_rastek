package com.example.userCrud.Entity;

public enum EducationLevel {
    SMP, SMA_SMK, Diploma, Sarjana, Magister
}
